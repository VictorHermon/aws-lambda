def log(text):
    print(text)
